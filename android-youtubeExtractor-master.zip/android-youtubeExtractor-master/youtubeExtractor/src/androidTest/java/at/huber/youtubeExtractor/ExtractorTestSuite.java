package at.huber.youtubeExtractor;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({ExtractorTestCases.class})
public class ExtractorTestSuite {}



